import React from 'react'
import ReactDOM from 'react-dom'
import HomePage from './component/HomePage.jsx'

ReactDOM.render(
    <HomePage />,
    document.getElementById("root"))
